'''imports'''
from datetime import date, datetime
import time
import threading
import playsound
import Communication.Output as out
import Communication.SpeechIn as ind

thread_status = False #yes the use of globals sucks, but I couldn't find an alternative

class TimeFunction:
    '''used for telling time and alarm'''
    def __init__(self) -> None:
        pass

    @staticmethod
    def tell_time():
        '''what time is it'''
        now = datetime.now()
        current_time = now.strftime("%H:%M")
        out.Output.say(f"The current time is {current_time}")

    @staticmethod
    def tell_date():
        '''what is the date'''
        today = date.today()
        out.Output.say(f"Today's date is {today}")

    @staticmethod
    def alarm_clock():
        '''alarm clock function'''
        text = "\nWake up!"
        out.Output.say("What time would you like your alarm to ring?")
        done = False
        while not done:
            alarm_hour, alarm_minute = TimeFunction.get_time_input()
            done = True
        out.Output.say(f"I have set your alarm to {alarm_hour} {alarm_minute}")
        x = threading.Thread(target = TimeFunction.alarm_function,
                            args = (alarm_hour, alarm_minute, text),
                            daemon = True)
        x.start()

    @staticmethod
    def get_time_input():
        '''get the desired alarm time'''
        exmessage = "I'm sorry, that was some weird input."
        alarm_time = ind.SpeechIn.listen().replace(":","").replace("/","")
        try:
            int(alarm_time)
        except ValueError:
            out.Output.say(exmessage)
            return
        try:
            len(str(alarm_time)) > 4
        except ValueError:
            out.Output.say(exmessage)
            return
        alarm_hour = alarm_time[0:2]
        if len(str(alarm_time)) == 3:
            alarm_hour = alarm_time[0:1]
        alarm_minute = alarm_time[2:4]
        if len(alarm_minute) == 1:
            alarm_minute = alarm_time[1:3]
        try:
            int(alarm_hour) < 25
        except ValueError:
            out.Output.say(exmessage)
            return
        try:
            int(alarm_minute) < 60
        except ValueError:
            out.Output.say(exmessage)
            return
        return alarm_hour, alarm_minute

    @staticmethod
    def alarm_function(alarm_hour, alarm_minute, text):
        '''after an alarm or reminder is set, this is the \"motor\"'''
        while True:
            now = datetime.now()
            current_hour = now.strftime("%H")
            current_minute = now.strftime("%M")
            if alarm_hour == current_hour:
                if alarm_minute == current_minute:
                    print(text)
                    playsound.playsound("App/Ressources/alarmClock.mp3")
                    break

    @staticmethod
    def pomodoro_timer(stop):
        '''pomodoro timer'''
        # omg the way I'm stopping this thread is not very elegant,
        # but because of the timers involved I don't want to have to go through
        # and entire pomodoro sequence before stopping.
        # The thread ends correctly even this way - no apparent casualties
        count = 0
        while True:
            if stop:
                break
            count += 1
            if count == 1:
                out.Output.say("Your pomodoro session starts now."
                            "Work for 25 minutes, then we'll take a short break.")
            out.Output.say("Time to get back to work! "
                            "I'll remind you to take another break in 25 minutes.")
            time.sleep(1500)
            if stop:
                break
            if count % 4 != 0:
                out.Output.say("Now it's time for a 5 minute break! "
                                f"You have completed {count} pomodoros so far.")
                time.sleep(300)
                if stop:
                    break
            out.Output.say("Now it's time for a longer break. "
                            "Strecth your legs for 20 minutes this time.")
            time.sleep(1200)
            if stop:
                break

    @staticmethod
    def run_pomodoro():
        '''start the pomodoro timer'''
        thread_status = False
        x = threading.Thread(target = TimeFunction.pomodoro_timer,
                            daemon = True,
                            args=(lambda: thread_status,))
        x.start()

    @staticmethod
    def stop_pomodoro():
        '''stop the pomodoro timer'''
        thread_status = True
        out.Output.say("Your pomodoro session will be stopped at the end of the current timer.")
